import React, { useState, useEffect, useRef } from 'react';
import {
  ChevronLeft, ChevronRight, User, Mail, Phone, Calendar,
  Loader2, AlertCircle, CheckCircle, ShieldCheck, ArrowRight,
  LogIn, UserPlus, Eye, EyeOff
} from 'lucide-react';
import { authService } from '../../services/auth.service';
import { patientService } from '../../services/patient.service';

interface Props {
  onBack: () => void;
  onSuccess: (user: any, token: string) => void;
}

type Mode  = 'choose' | 'create' | 'login';
type Stage = 'details' | 'otp';

/* ── OTP boxes — defined OUTSIDE the page component so React never
   unmounts/remounts the inputs on re-render, keeping focus smooth ── */
interface OtpBoxesProps {
  digits: string[];
  refs: React.MutableRefObject<(HTMLInputElement | null)[]>;
  devOtp?: string;
  onKeyDown: (index: number, e: React.KeyboardEvent<HTMLInputElement>) => void;
  onChange: (index: number, val: string) => void;
}

const OtpBoxes: React.FC<OtpBoxesProps> = ({ digits, devOtp, refs, onKeyDown, onChange }) => (
  <div className="space-y-4">
    <div className="flex gap-2 justify-center">
      {digits.map((d, i) => (
        <input
          key={i}
          ref={el => { refs.current[i] = el; }}
          type="text" inputMode="numeric" maxLength={1}
          value={d}
          onChange={e => onChange(i, e.target.value)}
          onKeyDown={e => onKeyDown(i, e)}
          autoFocus={i === 0}
          className="text-center text-xl font-bold rounded-xl transition-all"
          style={{
            background: d ? 'var(--primary-glow)' : 'var(--bg-elevated)',
            border: `2px solid ${d ? 'var(--border-accent)' : 'var(--border-medium)'}`,
            color: 'var(--text-primary)',
            width: '2.75rem', height: '3.25rem',
            outline: 'none',
          }}
          onFocus={e => { e.target.style.borderColor = 'var(--primary)'; e.target.style.boxShadow = '0 0 0 3px var(--primary-glow)'; }}
          onBlur={e  => { e.target.style.borderColor = d ? 'var(--border-accent)' : 'var(--border-medium)'; e.target.style.boxShadow = 'none'; }}
        />
      ))}
    </div>
    {devOtp && (
      <div className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs"
        style={{ background: 'rgba(6,182,212,0.07)', border: '1px solid var(--border-accent)', color: 'var(--primary-light)' }}>
        <ShieldCheck className="w-3.5 h-3.5 flex-shrink-0" />
        Dev OTP: <span className="font-mono font-bold tracking-widest">{devOtp}</span>
      </div>
    )}
  </div>
);

const AccountSetupPage: React.FC<Props> = ({ onBack, onSuccess }) => {
  const [mode, setMode] = useState<Mode>('choose');

  /* ── Create account state ─────────────────────────────────── */
  const [fullName, setFullName] = useState('');
  const [email,    setEmail]    = useState('');
  const [phone,    setPhone]    = useState('');
  const [age,      setAge]      = useState('');
  const [stage,    setStage]    = useState<Stage>('details');
  const [otpDigits, setOtpDigits] = useState(['','','','','','']);
  const [devOtp,   setDevOtp]   = useState('');
  const [resendTimer, setResendTimer] = useState(0);

  /* ── Login state ──────────────────────────────────────────── */
  const [loginPhone,    setLoginPhone]    = useState('');
  const [loginOtpDigits, setLoginOtpDigits] = useState(['','','','','','']);
  const [loginStage,    setLoginStage]    = useState<'phone' | 'otp'>('phone');
  const [loginDevOtp,   setLoginDevOtp]   = useState('');
  const [loginResendTimer, setLoginResendTimer] = useState(0);

  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState('');

  const createOtpRefs = useRef<(HTMLInputElement | null)[]>([]);
  const loginOtpRefs  = useRef<(HTMLInputElement | null)[]>([]);

  /* ── Resend timers ────────────────────────────────────────── */
  useEffect(() => {
    if (resendTimer <= 0) return;
    const t = setTimeout(() => setResendTimer(r => r - 1), 1000);
    return () => clearTimeout(t);
  }, [resendTimer]);

  useEffect(() => {
    if (loginResendTimer <= 0) return;
    const t = setTimeout(() => setLoginResendTimer(r => r - 1), 1000);
    return () => clearTimeout(t);
  }, [loginResendTimer]);

  /* ── Auto-submit when all OTP digits filled ───────────────── */
  useEffect(() => {
    if (stage === 'otp' && otpDigits.join('').length === 6 && !loading)
      handleVerifyCreateOtp();
  }, [otpDigits]);

  useEffect(() => {
    if (loginStage === 'otp' && loginOtpDigits.join('').length === 6 && !loading)
      handleVerifyLoginOtp();
  }, [loginOtpDigits]);

  /* ── OTP handlers (create) ───────────────────────────────── */
  const handleCreateOtpChange = (index: number, val: string) => {
    const ch = val.replace(/\D/g, '').slice(-1);
    if (!ch) return;
    setOtpDigits(prev => { const d = [...prev]; d[index] = ch; return d; });
    if (index < 5) createOtpRefs.current[index + 1]?.focus();
  };
  const handleCreateOtpKey = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace') {
      setOtpDigits(prev => {
        const d = [...prev];
        if (d[index]) { d[index] = ''; return d; }
        if (index > 0) { d[index - 1] = ''; createOtpRefs.current[index - 1]?.focus(); return d; }
        return d;
      });
    }
  };

  /* ── OTP handlers (login) ────────────────────────────────── */
  const handleLoginOtpChange = (index: number, val: string) => {
    const ch = val.replace(/\D/g, '').slice(-1);
    if (!ch) return;
    setLoginOtpDigits(prev => { const d = [...prev]; d[index] = ch; return d; });
    if (index < 5) loginOtpRefs.current[index + 1]?.focus();
  };
  const handleLoginOtpKey = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace') {
      setLoginOtpDigits(prev => {
        const d = [...prev];
        if (d[index]) { d[index] = ''; return d; }
        if (index > 0) { d[index - 1] = ''; loginOtpRefs.current[index - 1]?.focus(); return d; }
        return d;
      });
    }
  };

  /* ── CREATE ACCOUNT ───────────────────────────────────────── */
  const handleCreateSubmit = async () => {
    setError('');
    if (!fullName.trim()) { setError('Please enter your full name'); return; }
    if (!email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { setError('Please enter a valid email address'); return; }
    if (!phone.trim() || phone.replace(/\D/g,'').length < 10) { setError('Please enter a valid 10-digit phone number'); return; }
    if (!age || isNaN(+age) || +age < 1 || +age > 120) { setError('Please enter a valid age'); return; }

    setLoading(true);
    try {
      // Create patient record
      await patientService.create({
        full_name: fullName.trim(),
        email: email.trim().toLowerCase(),
        phone: phone.replace(/\D/g,''),
        age: parseInt(age),
      });
      // Send OTP to verify phone
      const otpRes = await authService.generateOTP(phone.replace(/\D/g,''));
      if (otpRes?.otp) setDevOtp(String(otpRes.otp));
      setStage('otp');
      setResendTimer(120);
    } catch (e: any) {
      const msg = e.response?.data?.message || e.message || 'Registration failed';
      setError(msg.includes('duplicate') || msg.includes('already') || msg.includes('unique')
        ? 'Email or phone number already registered. Try logging in instead.'
        : msg);
    } finally { setLoading(false); }
  };

  const handleVerifyCreateOtp = async () => {
    const code = otpDigits.join('');
    if (code.length < 6) return;
    setLoading(true); setError('');
    try {
      const res = await authService.verifyOTP(phone.replace(/\D/g,''), code);
      const token = res?.data?.accessToken || res?.accessToken || res?.token;
      const user  = res?.data?.user  || res?.user  || res?.patient;
      if (!token || !user) throw new Error('Verification failed — unexpected response shape');
      localStorage.setItem('accessToken', token);
      localStorage.setItem('user', JSON.stringify(user));
      onSuccess(user, token);
    } catch (e: any) {
      setError(e.response?.data?.message || 'Invalid OTP. Please try again.');
      setOtpDigits(['','','','','','']);
      createOtpRefs.current[0]?.focus();
    } finally { setLoading(false); }
  };

  const handleResendCreate = async () => {
    setLoading(true); setError('');
    try {
      const res = await authService.generateOTP(phone.replace(/\D/g,''));
      if (res?.otp) setDevOtp(String(res.otp));
      setResendTimer(120);
      setOtpDigits(['','','','','','']);
    } catch { setError('Failed to resend OTP'); }
    finally { setLoading(false); }
  };

  /* ── LOGIN ────────────────────────────────────────────────── */
  const handleLoginSendOtp = async () => {
    if (!loginPhone.trim() || loginPhone.replace(/\D/g,'').length < 10) {
      setError('Please enter a valid 10-digit phone number'); return;
    }
    setLoading(true); setError('');
    try {
      const res = await authService.generateOTP(loginPhone.replace(/\D/g,''));
      if (res?.otp) setLoginDevOtp(String(res.otp));
      setLoginStage('otp');
      setLoginResendTimer(120);
    } catch (e: any) {
      setError(e.response?.data?.message || 'Failed to send OTP. Please check your phone number.');
    } finally { setLoading(false); }
  };

  const handleVerifyLoginOtp = async () => {
    const code = loginOtpDigits.join('');
    if (code.length < 6) return;
    setLoading(true); setError('');
    try {
      const res = await authService.verifyOTP(loginPhone.replace(/\D/g,''), code);
      const token = res?.data?.accessToken || res?.accessToken || res?.token;
      const user  = res?.data?.user  || res?.user  || res?.patient;
      if (!token || !user) throw new Error('Verification failed — unexpected response shape');
      localStorage.setItem('accessToken', token);
      localStorage.setItem('user', JSON.stringify(user));
      onSuccess(user, token);
    } catch (e: any) {
      setError(e.response?.data?.message || 'Invalid OTP. Please try again.');
      setLoginOtpDigits(['','','','','','']);
      loginOtpRefs.current[0]?.focus();
    } finally { setLoading(false); }
  };


  /* ── Input field style ────────────────────────────────────── */
  const inputStyle: React.CSSProperties = {
    background: 'var(--bg-elevated)',
    border: '1px solid var(--border-medium)',
    color: 'var(--text-primary)',
    borderRadius: '0.75rem',
    padding: '0.75rem 1rem',
    fontSize: '0.875rem',
    width: '100%',
    outline: 'none',
    transition: 'border-color 0.15s',
  };

  /* ── CHOOSE screen ────────────────────────────────────────── */
  if (mode === 'choose') return (
    <div className="min-h-screen pb-10 flex flex-col" style={{ backgroundColor: 'var(--bg-deep)', color: 'var(--text-primary)' }}>

      {/* Header */}
      <div className="sticky top-0 z-10 backdrop-blur-sm px-4 py-3"
        style={{ background: 'rgba(7,14,26,0.95)', borderBottom: '1px solid var(--border-faint)' }}>
        <div className="max-w-2xl mx-auto flex items-center gap-3">
          <button onClick={onBack} className="p-2 rounded-xl transition-colors"
            style={{ background: 'var(--bg-surface)', border: '1px solid var(--border-faint)', color: 'var(--text-secondary)' }}>
            <ChevronLeft className="w-4 h-4" />
          </button>
          <div className="flex-1">
            <p className="text-xs" style={{ color: 'var(--text-muted)' }}>Step 3 of 5</p>
            <p className="text-sm font-semibold" style={{ color: 'var(--text-primary)' }}>Your Account</p>
          </div>
          <div className="flex gap-1.5">
            {[1,2,3,4,5].map(s => (
              <div key={s} className="h-2 rounded-full transition-all"
                style={{ width: s === 3 ? '20px' : '8px', background: s <= 3 ? 'var(--primary)' : 'var(--border-medium)' }} />
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-10 flex flex-col items-center gap-6 w-full">

        {/* Icon */}
        <div className="w-20 h-20 rounded-3xl flex items-center justify-center"
          style={{ background: 'linear-gradient(135deg, var(--primary-dark), var(--primary))', boxShadow: '0 8px 32px var(--primary-glow)' }}>
          <User className="w-10 h-10 text-white" />
        </div>

        <div className="text-center">
          <h2 className="text-xl font-bold" style={{ color: 'var(--text-primary)' }}>Almost there!</h2>
          <p className="text-sm mt-1.5" style={{ color: 'var(--text-muted)' }}>
            Create an account to book your session, or sign in if you already have one.
          </p>
        </div>

        <div className="flex flex-col gap-3 w-full max-w-sm">
          <button onClick={() => { setMode('create'); setError(''); }}
            className="flex items-center gap-3 px-5 py-4 rounded-2xl text-left transition-all"
            style={{ background: 'linear-gradient(135deg, var(--primary-dark), var(--primary))', boxShadow: '0 4px 20px var(--primary-glow)', color: '#fff' }}>
            <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center flex-shrink-0">
              <UserPlus className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <p className="font-bold text-sm">Create New Account</p>
              <p className="text-xs opacity-75 mt-0.5">Quick setup — just your name, email, phone &amp; age</p>
            </div>
            <ChevronRight className="w-4 h-4 opacity-60" />
          </button>

          <button onClick={() => { setMode('login'); setError(''); }}
            className="flex items-center gap-3 px-5 py-4 rounded-2xl text-left transition-all"
            style={{ background: 'var(--bg-surface)', border: '1px solid var(--border-faint)', color: 'var(--text-primary)' }}
            onMouseEnter={e => (e.currentTarget as HTMLElement).style.borderColor = 'var(--border-accent)'}
            onMouseLeave={e => (e.currentTarget as HTMLElement).style.borderColor = 'var(--border-faint)'}>
            <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
              style={{ background: 'var(--bg-elevated)' }}>
              <LogIn className="w-5 h-5" style={{ color: 'var(--primary-light)' }} />
            </div>
            <div className="flex-1">
              <p className="font-bold text-sm">I Already Have an Account</p>
              <p className="text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>Sign in with your phone number</p>
            </div>
            <ChevronRight className="w-4 h-4" style={{ color: 'var(--text-muted)' }} />
          </button>
        </div>
      </div>
    </div>
  );

  /* ── CREATE ACCOUNT screen ────────────────────────────────── */
  if (mode === 'create') return (
    <div className="min-h-screen pb-24" style={{ backgroundColor: 'var(--bg-deep)', color: 'var(--text-primary)' }}>

      {/* Header */}
      <div className="sticky top-0 z-10 backdrop-blur-sm px-4 py-3"
        style={{ background: 'rgba(7,14,26,0.95)', borderBottom: '1px solid var(--border-faint)' }}>
        <div className="max-w-2xl mx-auto flex items-center gap-3">
          <button onClick={() => { setMode('choose'); setError(''); setStage('details'); setOtpDigits(['','','','','','']); }}
            className="p-2 rounded-xl transition-colors"
            style={{ background: 'var(--bg-surface)', border: '1px solid var(--border-faint)', color: 'var(--text-secondary)' }}>
            <ChevronLeft className="w-4 h-4" />
          </button>
          <div className="flex-1">
            <p className="text-xs" style={{ color: 'var(--text-muted)' }}>Step 3 of 5</p>
            <p className="text-sm font-semibold" style={{ color: 'var(--text-primary)' }}>
              {stage === 'details' ? 'Create Account' : 'Verify Phone'}
            </p>
          </div>
          <div className="flex gap-1.5">
            {[1,2,3,4,5].map(s => (
              <div key={s} className="h-2 rounded-full transition-all"
                style={{ width: s === 3 ? '20px' : '8px', background: s <= 3 ? 'var(--primary)' : 'var(--border-medium)' }} />
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-6 space-y-5">

        {stage === 'details' ? (
          <>
            <div>
              <h2 className="text-lg font-bold" style={{ color: 'var(--text-primary)' }}>Create your account</h2>
              <p className="text-sm mt-1" style={{ color: 'var(--text-muted)' }}>
                Fill in your details to continue with booking.
              </p>
            </div>

            {/* Error */}
            {error && (
              <div className="flex items-start gap-3 px-4 py-3 rounded-xl"
                style={{ background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.3)' }}>
                <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" style={{ color: '#f87171' }} />
                <p className="text-sm" style={{ color: '#fca5a5' }}>{error}</p>
              </div>
            )}

            {/* Form */}
            <div className="rounded-2xl p-5 space-y-4"
              style={{ background: 'var(--bg-surface)', border: '1px solid var(--border-faint)' }}>

              {/* Full Name */}
              <div>
                <label className="text-xs font-semibold mb-1.5 flex items-center gap-1.5"
                  style={{ color: 'var(--text-secondary)', display: 'flex' }}>
                  <User className="w-3.5 h-3.5" /> Full Name
                </label>
                <input
                  value={fullName} onChange={e => setFullName(e.target.value)}
                  placeholder="Your full name"
                  style={inputStyle}
                  onFocus={e => e.target.style.borderColor = 'var(--primary)'}
                  onBlur={e  => e.target.style.borderColor = 'var(--border-medium)'}
                />
              </div>

              {/* Email */}
              <div>
                <label className="text-xs font-semibold mb-1.5 flex items-center gap-1.5"
                  style={{ color: 'var(--text-secondary)', display: 'flex' }}>
                  <Mail className="w-3.5 h-3.5" /> Email Address
                  <span className="text-[10px] px-1.5 py-0.5 rounded-full" style={{ background: 'var(--primary-glow)', color: 'var(--primary-light)' }}>
                    Unique
                  </span>
                </label>
                <input
                  type="email" value={email} onChange={e => setEmail(e.target.value)}
                  placeholder="your@email.com"
                  style={inputStyle}
                  onFocus={e => e.target.style.borderColor = 'var(--primary)'}
                  onBlur={e  => e.target.style.borderColor = 'var(--border-medium)'}
                />
              </div>

              {/* Phone */}
              <div>
                <label className="text-xs font-semibold mb-1.5 flex items-center gap-1.5"
                  style={{ color: 'var(--text-secondary)', display: 'flex' }}>
                  <Phone className="w-3.5 h-3.5" /> Contact Number
                  <span className="text-[10px] px-1.5 py-0.5 rounded-full" style={{ background: 'var(--primary-glow)', color: 'var(--primary-light)' }}>
                    Unique
                  </span>
                </label>
                <div className="flex gap-2">
                  <div className="flex items-center px-3 rounded-xl flex-shrink-0 text-sm font-medium"
                    style={{ background: 'var(--bg-elevated)', border: '1px solid var(--border-medium)', color: 'var(--text-secondary)' }}>
                    +91
                  </div>
                  <input
                    type="tel" value={phone} onChange={e => setPhone(e.target.value.replace(/\D/g,'').slice(0,10))}
                    placeholder="10-digit mobile number"
                    style={{ ...inputStyle }}
                    onFocus={e => e.target.style.borderColor = 'var(--primary)'}
                    onBlur={e  => e.target.style.borderColor = 'var(--border-medium)'}
                  />
                </div>
              </div>

              {/* Age */}
              <div>
                <label className="text-xs font-semibold mb-1.5 flex items-center gap-1.5"
                  style={{ color: 'var(--text-secondary)', display: 'flex' }}>
                  <Calendar className="w-3.5 h-3.5" /> Age
                </label>
                <input
                  type="number" value={age} onChange={e => setAge(e.target.value)}
                  placeholder="Your age" min={1} max={120}
                  style={{ ...inputStyle, width: '8rem' }}
                  onFocus={e => e.target.style.borderColor = 'var(--primary)'}
                  onBlur={e  => e.target.style.borderColor = 'var(--border-medium)'}
                />
              </div>
            </div>
          </>
        ) : (
          /* OTP verification step */
          <>
            <div className="text-center">
              <div className="w-16 h-16 rounded-2xl mx-auto flex items-center justify-center mb-4"
                style={{ background: 'var(--primary-glow)', border: '1px solid var(--border-accent)' }}>
                <ShieldCheck className="w-8 h-8" style={{ color: 'var(--primary-light)' }} />
              </div>
              <h2 className="text-lg font-bold" style={{ color: 'var(--text-primary)' }}>Verify your phone</h2>
              <p className="text-sm mt-1.5" style={{ color: 'var(--text-muted)' }}>
                Enter the 6-digit OTP sent to <strong style={{ color: 'var(--text-secondary)' }}>+91 {phone}</strong>
              </p>
            </div>

            {error && (
              <div className="flex items-center gap-2 px-4 py-3 rounded-xl"
                style={{ background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.3)' }}>
                <AlertCircle className="w-4 h-4 flex-shrink-0" style={{ color: '#f87171' }} />
                <p className="text-sm" style={{ color: '#fca5a5' }}>{error}</p>
              </div>
            )}

            <OtpBoxes digits={otpDigits} refs={createOtpRefs} devOtp={devOtp}
              onChange={handleCreateOtpChange} onKeyDown={handleCreateOtpKey} />

            <div className="text-center">
              {resendTimer > 0 ? (
                <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
                  Resend in {Math.floor(resendTimer/60)}:{String(resendTimer%60).padStart(2,'0')}
                </p>
              ) : (
                <button onClick={handleResendCreate} disabled={loading}
                  className="text-xs font-medium transition-opacity hover:opacity-70"
                  style={{ color: 'var(--primary-light)' }}>
                  Resend OTP
                </button>
              )}
            </div>
          </>
        )}
      </div>

      {/* Sticky CTA */}
      <div className="fixed bottom-0 left-0 right-0 px-4 py-4"
        style={{ background: 'rgba(7,14,26,0.97)', borderTop: '1px solid var(--border-faint)', backdropFilter: 'blur(16px)' }}>
        <div className="max-w-2xl mx-auto">
          {stage === 'details' ? (
            <button onClick={handleCreateSubmit} disabled={loading}
              className="w-full flex items-center justify-center gap-2 py-3.5 rounded-2xl text-sm font-bold text-white transition-all disabled:opacity-60"
              style={{ background: 'linear-gradient(135deg, var(--primary-dark), var(--primary))', boxShadow: '0 4px 20px var(--primary-glow)' }}>
              {loading ? <><Loader2 className="w-4 h-4 animate-spin" /> Creating account…</> : <>Continue <ChevronRight className="w-4 h-4" /></>}
            </button>
          ) : (
            <button onClick={handleVerifyCreateOtp} disabled={loading || otpDigits.join('').length < 6}
              className="w-full flex items-center justify-center gap-2 py-3.5 rounded-2xl text-sm font-bold text-white transition-all disabled:opacity-60"
              style={{ background: 'linear-gradient(135deg, var(--primary-dark), var(--primary))', boxShadow: '0 4px 20px var(--primary-glow)' }}>
              {loading ? <><Loader2 className="w-4 h-4 animate-spin" /> Verifying…</> : <><CheckCircle className="w-4 h-4" /> Verify &amp; Continue</>}
            </button>
          )}
        </div>
      </div>
    </div>
  );

  /* ── LOGIN screen ─────────────────────────────────────────── */
  return (
    <div className="min-h-screen pb-24" style={{ backgroundColor: 'var(--bg-deep)', color: 'var(--text-primary)' }}>

      {/* Header */}
      <div className="sticky top-0 z-10 backdrop-blur-sm px-4 py-3"
        style={{ background: 'rgba(7,14,26,0.95)', borderBottom: '1px solid var(--border-faint)' }}>
        <div className="max-w-2xl mx-auto flex items-center gap-3">
          <button onClick={() => { setMode('choose'); setError(''); setLoginStage('phone'); setLoginOtpDigits(['','','','','','']); }}
            className="p-2 rounded-xl transition-colors"
            style={{ background: 'var(--bg-surface)', border: '1px solid var(--border-faint)', color: 'var(--text-secondary)' }}>
            <ChevronLeft className="w-4 h-4" />
          </button>
          <div className="flex-1">
            <p className="text-xs" style={{ color: 'var(--text-muted)' }}>Step 3 of 5</p>
            <p className="text-sm font-semibold" style={{ color: 'var(--text-primary)' }}>
              {loginStage === 'phone' ? 'Sign In' : 'Verify OTP'}
            </p>
          </div>
          <div className="flex gap-1.5">
            {[1,2,3,4,5].map(s => (
              <div key={s} className="h-2 rounded-full transition-all"
                style={{ width: s === 3 ? '20px' : '8px', background: s <= 3 ? 'var(--primary)' : 'var(--border-medium)' }} />
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-6 space-y-5">

        {loginStage === 'phone' ? (
          <>
            <div>
              <h2 className="text-lg font-bold" style={{ color: 'var(--text-primary)' }}>Sign in to your account</h2>
              <p className="text-sm mt-1" style={{ color: 'var(--text-muted)' }}>
                Enter your registered phone number to receive an OTP.
              </p>
            </div>

            {error && (
              <div className="flex items-center gap-2 px-4 py-3 rounded-xl"
                style={{ background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.3)' }}>
                <AlertCircle className="w-4 h-4 flex-shrink-0" style={{ color: '#f87171' }} />
                <p className="text-sm" style={{ color: '#fca5a5' }}>{error}</p>
              </div>
            )}

            <div className="rounded-2xl p-5"
              style={{ background: 'var(--bg-surface)', border: '1px solid var(--border-faint)' }}>
              <label className="text-xs font-semibold mb-2 flex items-center gap-1.5"
                style={{ color: 'var(--text-secondary)', display: 'flex' }}>
                <Phone className="w-3.5 h-3.5" /> Phone Number
              </label>
              <div className="flex gap-2">
                <div className="flex items-center px-3 rounded-xl flex-shrink-0 text-sm font-medium"
                  style={{ background: 'var(--bg-elevated)', border: '1px solid var(--border-medium)', color: 'var(--text-secondary)' }}>
                  +91
                </div>
                <input
                  type="tel" value={loginPhone} onChange={e => setLoginPhone(e.target.value.replace(/\D/g,'').slice(0,10))}
                  placeholder="Registered phone number"
                  style={inputStyle}
                  onFocus={e => e.target.style.borderColor = 'var(--primary)'}
                  onBlur={e  => e.target.style.borderColor = 'var(--border-medium)'}
                />
              </div>
            </div>

            <div className="text-center">
              <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
                Don't have an account?{' '}
                <button onClick={() => { setMode('create'); setError(''); }}
                  className="font-semibold" style={{ color: 'var(--primary-light)' }}>
                  Create one
                </button>
              </p>
            </div>
          </>
        ) : (
          <>
            <div className="text-center">
              <div className="w-16 h-16 rounded-2xl mx-auto flex items-center justify-center mb-4"
                style={{ background: 'var(--primary-glow)', border: '1px solid var(--border-accent)' }}>
                <ShieldCheck className="w-8 h-8" style={{ color: 'var(--primary-light)' }} />
              </div>
              <h2 className="text-lg font-bold" style={{ color: 'var(--text-primary)' }}>Enter your OTP</h2>
              <p className="text-sm mt-1.5" style={{ color: 'var(--text-muted)' }}>
                Sent to <strong style={{ color: 'var(--text-secondary)' }}>+91 {loginPhone}</strong>
              </p>
            </div>

            {error && (
              <div className="flex items-center gap-2 px-4 py-3 rounded-xl"
                style={{ background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.3)' }}>
                <AlertCircle className="w-4 h-4 flex-shrink-0" style={{ color: '#f87171' }} />
                <p className="text-sm" style={{ color: '#fca5a5' }}>{error}</p>
              </div>
            )}

            <OtpBoxes digits={loginOtpDigits} refs={loginOtpRefs} devOtp={loginDevOtp}
              onChange={handleLoginOtpChange} onKeyDown={handleLoginOtpKey} />

            <div className="text-center">
              {loginResendTimer > 0 ? (
                <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
                  Resend in {Math.floor(loginResendTimer/60)}:{String(loginResendTimer%60).padStart(2,'0')}
                </p>
              ) : (
                <button onClick={handleLoginSendOtp} disabled={loading}
                  className="text-xs font-medium transition-opacity hover:opacity-70"
                  style={{ color: 'var(--primary-light)' }}>
                  Resend OTP
                </button>
              )}
            </div>
          </>
        )}
      </div>

      {/* Sticky CTA */}
      <div className="fixed bottom-0 left-0 right-0 px-4 py-4"
        style={{ background: 'rgba(7,14,26,0.97)', borderTop: '1px solid var(--border-faint)', backdropFilter: 'blur(16px)' }}>
        <div className="max-w-2xl mx-auto">
          {loginStage === 'phone' ? (
            <button onClick={handleLoginSendOtp} disabled={loading}
              className="w-full flex items-center justify-center gap-2 py-3.5 rounded-2xl text-sm font-bold text-white transition-all disabled:opacity-60"
              style={{ background: 'linear-gradient(135deg, var(--primary-dark), var(--primary))', boxShadow: '0 4px 20px var(--primary-glow)' }}>
              {loading ? <><Loader2 className="w-4 h-4 animate-spin" /> Sending OTP…</> : <>Send OTP <ArrowRight className="w-4 h-4" /></>}
            </button>
          ) : (
            <button onClick={handleVerifyLoginOtp} disabled={loading || loginOtpDigits.join('').length < 6}
              className="w-full flex items-center justify-center gap-2 py-3.5 rounded-2xl text-sm font-bold text-white transition-all disabled:opacity-60"
              style={{ background: 'linear-gradient(135deg, var(--primary-dark), var(--primary))', boxShadow: '0 4px 20px var(--primary-glow)' }}>
              {loading ? <><Loader2 className="w-4 h-4 animate-spin" /> Verifying…</> : <><CheckCircle className="w-4 h-4" /> Sign In &amp; Continue</>}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default AccountSetupPage;
